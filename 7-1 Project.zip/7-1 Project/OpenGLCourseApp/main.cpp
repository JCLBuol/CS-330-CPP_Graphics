#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

#include <stdio.h>
#include <string.h>
#include <iostream>

#include <glm/gtc/type_ptr.hpp>
#include <GL\glew.h>
#include <GLFW\glfw3.h>
#include <GL\GL.h>
#include <glm\glm.hpp>
#include <glm\gtc\matrix_transform.hpp>
#include <glm\gtc\type_ptr.hpp>
#include <vector>
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif


using namespace std;




// Window dimensions
const GLint WIDTH = 800, HEIGHT = 600;

GLuint VBO, VAO, EBO, VAO_PLANE, VBO_PLANE, EBO_PLANE, VAO_CYLINDER, VBO_CYLINDER, VAO_CYLINDER2, VBO_CYLINDER2, VAO_SPHERE, VBO_SPHERE, EBO_SPHERE,
		VAO_SPHERE2, VBO_SPHERE2, EBO_SPHERE2, VAO_CUBE, VBO_CUBE, VAO_INNER_CYLINDER, VBO_INNER_CYLINDER, shaderTexture, lightShader;

// Vertex Shader code
static const char* vShader = "                                                \n\
#version 330                                                                  \n\
                                                                              \n\
layout (location = 0) in vec3 pos;											  \n\
layout (location = 1) in vec3 normal;										  \n\
layout (location = 2) in vec2 inTexCoord;                                     \n\
out vec2 Texcoord;                                                            \n\
out vec3 Normal;															  \n\
out vec3 FragPos;															  \n\
                                											  \n\
uniform mat4 model;                                                           \n\
uniform mat4 view;															  \n\
uniform mat4 projection;													  \n\
                                                                              \n\
void main()                                                                   \n\
{                                                                             \n\
    gl_Position = projection * view * model * vec4(pos, 1.0);      			  \n\
	FragPos = vec3(model * vec4(pos, 1.0));									  \n\
	Normal = mat3(transpose(inverse(model))) * normal;						  \n\
    Texcoord = inTexCoord;                                                    \n\
}";


// Texture Fragment Shader
static const char* fShaderTexture = "																	\n\
#version 330																							\n\
																										\n\
in vec2 Texcoord;																						\n\
in vec3 Normal;																							\n\
in vec3 FragPos;																						\n\
out vec4 outColor;																						\n\
uniform sampler2D texture1;																				\n\
																										\n\
uniform vec3 lightPos1;																					\n\
uniform vec3 lightColor1;																				\n\
uniform vec3 lightPos2;																					\n\
uniform vec3 lightColor2;																				\n\
uniform vec3 viewPos;																					\n\
uniform vec3 specularColor;																				\n\
uniform float shininess;																				\n\
																										\n\
void main()																								\n\
{																										\n\
	vec3 norm = normalize(Normal);																		\n\
	vec3 lightDir1 = normalize(lightPos1 - FragPos);													\n\
	vec3 lightDir2 = normalize(lightPos2 - FragPos);													\n\
																										\n\
	// Diffuse shading																					\n\
	float diff1 = max(dot(norm, lightDir1), 0.0);														\n\
	float diff2 = max(dot(norm, lightDir2), 0.0);														\n\
																										\n\
	// Specular shading																					\n\
	vec3 viewDir = normalize(viewPos - FragPos);														\n\
	vec3 reflectDir1 = reflect(-lightDir1, norm);														\n\
	vec3 reflectDir2 = reflect(-lightDir2, norm);														\n\
	float spec1 = pow(max(dot(viewDir, reflectDir1), 0.0), shininess);									\n\
	float spec2 = pow(max(dot(viewDir, reflectDir2), 0.0), shininess);									\n\
																										\n\
	vec3 ambient = 0.2 * vec3(texture(texture1, Texcoord));												\n\
	vec3 diffuse = (diff1 * lightColor1 + diff2 * lightColor2) * vec3(texture(texture1, Texcoord));		\n\
	vec3 specular = (spec1 * lightColor1 + spec2 * lightColor2) * specularColor;						\n\
																										\n\
	vec3 result = ambient + diffuse + specular;															\n\
	outColor = vec4(result, 1.0);																		\n\
	}";

// Light object Vertex shader
static const char* vlightShader = "								\n\
#version 330													\n\
layout(location = 0) in vec3 aPos;								\n\
																\n\
uniform mat4 model;												\n\
uniform mat4 view;												\n\
uniform mat4 projection;										\n\
																\n\
void main()														\n\
{																\n\
	gl_Position = projection * view * model * vec4(aPos, 1.0);	\n\
}";

// Light object Fragment shader
static const char* flightShader = "								\n\
#version 330													\n\
out vec4 FragColor;												\n\
																\n\
void main()														\n\
{																\n\
	FragColor = vec4(1.0, 1.0, 1.0, 1.0);						\n\
}";

void CreatePlane()
{
	GLfloat vertices[] = {
	-1.5f, -1.0f, 0.0f,  0.0f, 1.0f, 0.0f,  0.0f, 0.0f,  // bottom left
	 1.5f, -1.0f, 0.0f,  0.0f, 1.0f, 0.0f,  1.0f, 0.0f,  // bottom right
	-1.5f,  1.0f, 0.0f,  0.0f, 1.0f, 0.0f,  0.0f, 1.0f,  // top left 
	 1.5f, -1.0f, 0.0f,  0.0f, 1.0f, 0.0f,  1.0f, 0.0f,  // bottom right
	-1.5f,  1.0f, 0.0f,  0.0f, 1.0f, 0.0f,  0.0f, 1.0f,  // top left
	 1.5f,  1.0f, 0.0f,  0.0f, 1.0f, 0.0f,  1.0f, 1.0f,  // top right	

	};

	glGenVertexArrays(1, &VAO_PLANE);
	glBindVertexArray(VAO_PLANE);

	glGenBuffers(1, &VBO_PLANE);
	glBindBuffer(GL_ARRAY_BUFFER, VBO_PLANE);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), 0);
	glEnableVertexAttribArray(0);

	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
	glEnableVertexAttribArray(1);

	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));
	glEnableVertexAttribArray(2);

	glBindBuffer(GL_ARRAY_BUFFER, 0);

	glBindVertexArray(0);
}

GLuint loadTexture(char const* path)
{
	GLuint textureID;
	glGenTextures(1, &textureID);

	int width, height, nrComponents;
	unsigned char* data = stbi_load(path, &width, &height, &nrComponents, 0);
	if (data)
	{
		GLenum format;
		if (nrComponents == 1)
			format = GL_RED;
		else if (nrComponents == 3)
			format = GL_RGB;
		else if (nrComponents == 4)
			format = GL_RGBA;

		glBindTexture(GL_TEXTURE_2D, textureID);
		glTexImage2D(GL_TEXTURE_2D, 0, format, width, height, 0, format, GL_UNSIGNED_BYTE, data);
		glGenerateMipmap(GL_TEXTURE_2D);

		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		stbi_image_free(data);
	}

	else
	{
		cout << "Texture failed to load at path: " << path << endl;
	}

	return textureID;
}

vector<unsigned int> indices;
vector<float> vertices;

void CreateTorus()							// cration of the doughnut
{
	unsigned int ringCount = 100;
	unsigned int sectorCount = 100;

	float radius = 0.3f;
	float tubeRadius = 0.10f;

	vertices.clear();
	vertices.reserve(ringCount * sectorCount * 11);
	indices.clear();
	indices.reserve(ringCount * sectorCount * 6);

	float dTheta = 2.0f * M_PI / float(ringCount);
	float dPhi = 2.0f * M_PI / float(sectorCount);
	for (int ring = 0; ring <= ringCount; ++ring)
	{
		float theta = float(ring) * dTheta;
		float cosTheta = cosf(theta), sinTheta = sinf(theta);
		for (unsigned int sect = 0; sect <= sectorCount; ++sect)
		{
			float phi = float(sect) * dPhi;
			float cosPhi = cosf(phi), sinPhi = sinf(phi);

			// Vertex position
			glm::vec3 pos = glm::vec3((radius + tubeRadius * cosTheta) * cosPhi,
				(radius + tubeRadius * cosTheta) * sinPhi,
				tubeRadius * sinTheta);

			// Normal
			glm::vec3 center = glm::vec3(radius * cosPhi, radius * sinPhi, 0.0f);
			glm::vec3 normal = glm::normalize(pos - center);

			// Texture coordinates
			float u = float(ring) / ringCount;
			float v = float(sect) / sectorCount;

			// Interleave position and color
			vertices.push_back(pos.x);
			vertices.push_back(pos.y);
			vertices.push_back(pos.z);
			vertices.push_back(normal.x);
			vertices.push_back(normal.y);
			vertices.push_back(normal.z);
			vertices.push_back(u);
			vertices.push_back(v);
		}
	}

	// Indices
	for (int ring = 0; ring < ringCount; ++ring)
	{
		for (int sect = 0; sect < sectorCount; ++sect)
		{
			int k1 = (ring * (sectorCount + 1)) + sect;
			int k2 = k1 + sectorCount + 1;

			indices.push_back(k1);
			indices.push_back(k2);
			indices.push_back(k1 + 1);

			indices.push_back(k2);
			indices.push_back(k2 + 1);
			indices.push_back(k1 + 1);
		}
	}

	glGenVertexArrays(1, &VAO);
	glBindVertexArray(VAO);

	// Generate VBO and load vertices into it
	glGenBuffers(1, &VBO);
	glBindBuffer(GL_ARRAY_BUFFER, VBO);
	glBufferData(GL_ARRAY_BUFFER, vertices.size() * sizeof(float), &vertices[0], GL_STATIC_DRAW);

	// Generate EBO and load indices into it
	glGenBuffers(1, &EBO);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.size() * sizeof(unsigned int), &indices[0], GL_STATIC_DRAW);

	// Configure vertex attributes
	// Vertex position attribute
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);
	// Normal attribute
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
	glEnableVertexAttribArray(1);
	// Texture coordinate attribute
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
	glEnableVertexAttribArray(2);

	// Unbind VAO
	glBindVertexArray(0);
}

void CreateCylinder(bool createInnerCylinder = false)				// creation of the glass of juice
{
	// Cylinder parameters
	unsigned int sectorCount = 100;  // Number of segments around the cylinder
	unsigned int stackCount = 50;    // Number of segments along the height of the cylinder
	float radius = createInnerCylinder ? 0.28f : 0.3f;             // Radius of the cylinder
	float height = createInnerCylinder ? 0.55f : 0.6f;             // Height of the cylinder

	// Temporary storage for vertex data and indices
	std::vector<float> vertices;
	std::vector<unsigned int> indices;

	// Compute vertices and indices
	float sectorStep = 2 * M_PI / sectorCount;
	float stackStep = height / stackCount;
	for (unsigned int i = 0; i <= stackCount; ++i)
	{
		float stackHeight = i * stackStep;
		float v = (float)i / stackCount;

		for (unsigned int j = 0; j <= sectorCount; ++j)
		{
			float sectorAngle = j * sectorStep;
			float u = (float)j / sectorCount;
			float x = radius * cos(sectorAngle);
			float z = radius * sin(sectorAngle);

			// Add vertex position and color
			vertices.push_back(x);
			vertices.push_back(stackHeight);
			vertices.push_back(z);
			vertices.push_back(1.0f);
			vertices.push_back(0.6f);
			vertices.push_back(0.0f);
			vertices.push_back(u);
			vertices.push_back(v);


			// Add indices
			if (i < stackCount)
			{
				int k1 = i * (sectorCount + 1) + j;
				int k2 = k1 + sectorCount + 1;

				indices.push_back(k1);
				indices.push_back(k2);
				indices.push_back(k1 + 1);

				indices.push_back(k2);
				indices.push_back(k2 + 1);
				indices.push_back(k1 + 1);
			}
		}
	}

	if (createInnerCylinder)
	{
		// vertices and indices for the top cap
		float yTop = height;

		// Add the center vertex for the top cap
		vertices.push_back(0.0f);     // Vertex position (x)
		vertices.push_back(yTop);     // Vertex position (y)
		vertices.push_back(0.0f);     // Vertex position (z)
		vertices.push_back(1.0f);     // Vertex color (R)
		vertices.push_back(0.5f);     // Vertex color (G)
		vertices.push_back(0.0f);     // Vertex color (B)
		vertices.push_back(0.5f);
		vertices.push_back(0.5f);

		unsigned int topCenterIndex = static_cast<unsigned int>(vertices.size() / 8) - 1;

		// Add the vertices for the top cap
		for (unsigned int j = 0; j <= sectorCount; ++j)
		{
			float sectorAngle = j * sectorStep;
			float x = radius * cos(sectorAngle);
			float z = radius * sin(sectorAngle);

			// Add vertex position and color
			vertices.push_back(x);
			vertices.push_back(yTop);
			vertices.push_back(z);
			vertices.push_back(1.0f);
			vertices.push_back(0.5f);
			vertices.push_back(0.0f);

			float u = 0.5f + 0.5f * cos(sectorAngle);
			float v = 0.5f + 0.5f * sin(sectorAngle);

			vertices.push_back(u);
			vertices.push_back(v);

			// Add indices
			if (j < sectorCount)
			{
				unsigned int k1 = topCenterIndex;
				unsigned int k2 = topCenterIndex + j + 1;
				unsigned int k3 = topCenterIndex + j + 2;

				indices.push_back(k1);
				indices.push_back(k2);
				indices.push_back(k3);
			}
		}
	}
	if (createInnerCylinder)
	{
		glGenVertexArrays(1, &VAO_INNER_CYLINDER);
		glBindVertexArray(VAO_INNER_CYLINDER);

		glGenBuffers(1, &VBO_INNER_CYLINDER);
		glBindBuffer(GL_ARRAY_BUFFER, VBO_INNER_CYLINDER);
		glBufferData(GL_ARRAY_BUFFER, vertices.size() * sizeof(float), vertices.data(), GL_STATIC_DRAW);

		GLuint EBO;
		glGenBuffers(1, &EBO);
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
		glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.size() * sizeof(unsigned int), indices.data(), GL_STATIC_DRAW);

		// Configure vertex attributes
		glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
		glEnableVertexAttribArray(0);
		glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
		glEnableVertexAttribArray(1);
		glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));
		glEnableVertexAttribArray(2);
	}

	else
	{
		// Generate and bind VAO
		glGenVertexArrays(1, &VAO_CYLINDER);
		glBindVertexArray(VAO_CYLINDER);

		// Generate and bind VBO
		glGenBuffers(1, &VBO_CYLINDER);
		glBindBuffer(GL_ARRAY_BUFFER, VBO_CYLINDER);
		glBufferData(GL_ARRAY_BUFFER, vertices.size() * sizeof(float), vertices.data(), GL_STATIC_DRAW);

		// Generate EBO and load indices into it
		GLuint EBO;
		glGenBuffers(1, &EBO);
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
		glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.size() * sizeof(unsigned int), indices.data(), GL_STATIC_DRAW);

		// Configure vertex attributes
		glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0); // Vertex position
		glEnableVertexAttribArray(0);
		glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float))); // RGB color 
		glEnableVertexAttribArray(1);
		glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float))); // Texture coords
		glEnableVertexAttribArray(2);
	}

	// Unbind VAO
	glBindVertexArray(0);
}

void CreateCylinder2()				// creation of pancake
{
	// Cylinder parameters
	unsigned int sectorCount = 100;  // Number of segments around the cylinder
	unsigned int stackCount = 50;    // Number of segments along the height of the cylinder
	float radius = 0.4f;             // Radius of the cylinder
	float height = 0.05f;             // Height of the cylinder

	// Temporary storage for vertex data and indices
	std::vector<float> vertices;
	std::vector<unsigned int> indices;

	// Compute vertices and indices
	float sectorStep = 2 * M_PI / sectorCount;
	float stackStep = height / stackCount;
	for (unsigned int i = 0; i <= stackCount; ++i)
	{
		float stackHeight = i * stackStep;
		float v = (float)i / stackCount;

		for (unsigned int j = 0; j <= sectorCount; ++j)
		{
			float sectorAngle = j * sectorStep;
			float x = radius * cos(sectorAngle);
			float z = radius * sin(sectorAngle);
			float u = (float)j / sectorCount;

			// Add vertex position and color 
			vertices.push_back(x);
			vertices.push_back(stackHeight);
			vertices.push_back(z);
			vertices.push_back(0.8f);
			vertices.push_back(0.6f);
			vertices.push_back(0.2f);
			vertices.push_back(u);
			vertices.push_back(v);

			// Add indices
			if (i < stackCount)
			{
				int k1 = i * (sectorCount + 1) + j;
				int k2 = k1 + sectorCount + 1;

				indices.push_back(k1);
				indices.push_back(k2);
				indices.push_back(k1 + 1);

				indices.push_back(k2);
				indices.push_back(k2 + 1);
				indices.push_back(k1 + 1);
			}
		}
	}
	// Generate top cap vertices and indices
	float yTop = height * 0.5f;
	vertices.push_back(0.0f);  // Vertex position (x)
	vertices.push_back(yTop);  // Vertex position (y)
	vertices.push_back(0.0f);  // Vertex position (z)
	vertices.push_back(0.8f);  // Vertex color (R)
	vertices.push_back(0.6f);  // Vertex color (G)
	vertices.push_back(0.2f);  // Vertex color (B)
	vertices.push_back(0.5f);  // Texture coordinate (u)
	vertices.push_back(0.5f);  // Texture coordinate (v)

	unsigned int topCenterIndex = static_cast<unsigned int>(vertices.size() / 8) - 1;

	for (unsigned int j = 0; j <= sectorCount; ++j)
	{
		float sectorAngle = j * sectorStep;
		float x = radius * cos(sectorAngle);
		float z = radius * sin(sectorAngle);

		// Add vertex position and color
		vertices.push_back(x);
		vertices.push_back(yTop);
		vertices.push_back(z);
		vertices.push_back(0.8f);
		vertices.push_back(0.6f);
		vertices.push_back(0.2f);

		// compute texture coordinates for the top cap vertices
		float u = 0.5f + 0.5f * cos(sectorAngle);
		float v = 0.5f + 0.5f * sin(sectorAngle);

		vertices.push_back(u);
		vertices.push_back(v);

		// Add indices
		if (j < sectorCount)
		{
			unsigned int k1 = topCenterIndex;
			unsigned int k2 = topCenterIndex + j + 1;
			unsigned int k3 = topCenterIndex + j + 2;

			indices.push_back(k1);
			indices.push_back(k2);
			indices.push_back(k3);
		}
	}

	// Update the top cap vertices' y-coordinates to align with the top of the cylinder
	for (unsigned int j = 0; j <= sectorCount; ++j)
	{
		// Calculate the index of the top cap vertex
		unsigned int vertexIndex = topCenterIndex + j + 1;

		// Update the y-coordinate of the vertex to align with the top of the cylinder
		vertices[vertexIndex * 8 + 1] = height;
	}

	// Generate and bind VAO
	glGenVertexArrays(1, &VAO_CYLINDER2);
	glBindVertexArray(VAO_CYLINDER2);

	// Generate and bind VBO
	glGenBuffers(1, &VBO_CYLINDER2);
	glBindBuffer(GL_ARRAY_BUFFER, VBO_CYLINDER2);
	glBufferData(GL_ARRAY_BUFFER, vertices.size() * sizeof(float), vertices.data(), GL_STATIC_DRAW);

	// Generate EBO and load indices into it
	GLuint EBO;
	glGenBuffers(1, &EBO);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.size() * sizeof(unsigned int), indices.data(), GL_STATIC_DRAW);

	// Configure vertex attributes
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0); // Vertex position
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float))); // Vertex color
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float))); // Texture coords
	glEnableVertexAttribArray(2);


	// Unbind VAO
	glBindVertexArray(0);
}

void CreateSphere()			//  Creation of the tomato
{
	// Sphere parameters
	float radius = 0.3f;
	unsigned int sectorCount = 36;
	unsigned int stackCount = 18;

	// Temporary storage for vertex data and indices
	std::vector<float> vertices;
	std::vector<unsigned int> indices;

	// Compute vertices and indices
	float sectorStep = 2 * M_PI / sectorCount;
	float stackStep = M_PI / stackCount;

	for (unsigned int i = 0; i <= stackCount; ++i)
	{
		float stackAngle = M_PI / 2 - i * stackStep;
		float xy = radius * cosf(stackAngle);
		float z = radius * sinf(stackAngle);

		for (unsigned int j = 0; j <= sectorCount; ++j)
		{
			float sectorAngle = j * sectorStep;
			float x = xy * cosf(sectorAngle);
			float y = xy * sinf(sectorAngle);

			// Add vertex position 
			vertices.push_back(x);
			vertices.push_back(y);
			vertices.push_back(z);

			// Compute and add normals
			glm::vec3 norm = glm::normalize(glm::vec3(x, y, z));
			vertices.push_back(norm.x);
			vertices.push_back(norm.y);
			vertices.push_back(norm.z);

			// Add texture coordinates
			float u = (float)j / sectorCount;
			float v = (float)i / stackCount;
			vertices.push_back(u);
			vertices.push_back(v);


			// Add indices
			if (i < stackCount && j < sectorCount)
			{
				int k1 = i * (sectorCount + 1) + j;
				int k2 = k1 + 1;
				int k3 = (i + 1) * (sectorCount + 1) + j;
				int k4 = k3 + 1;

				indices.push_back(k1);
				indices.push_back(k3);
				indices.push_back(k2);

				indices.push_back(k2);
				indices.push_back(k3);
				indices.push_back(k4);
			}
		}
	}
	// Generate and bind VAO
	glGenVertexArrays(1, &VAO_SPHERE);
	glBindVertexArray(VAO_SPHERE);

	// Generate and bind VBO
	glGenBuffers(1, &VBO_SPHERE);
	glBindBuffer(GL_ARRAY_BUFFER, VBO_SPHERE);
	glBufferData(GL_ARRAY_BUFFER, vertices.size() * sizeof(float), vertices.data(), GL_STATIC_DRAW);

	// Generate EBO and load indices into it
	glGenBuffers(1, &EBO_SPHERE);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO_SPHERE);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.size() * sizeof(unsigned int), indices.data(), GL_STATIC_DRAW);

	// Configure vertex attributes
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);  // Vertex position
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));  // Normal
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));  // Texture coordinates
	glEnableVertexAttribArray(2);

	// Unbind VAO
	glBindVertexArray(0);

}

void CreateSphere2()			//  Creation of the light objects
{
	// Sphere parameters
	float radius = 0.3f;
	unsigned int sectorCount = 36;
	unsigned int stackCount = 18;

	// Temporary storage for vertex data and indices
	std::vector<float> vertices;
	std::vector<unsigned int> indices;

	// Compute vertices and indices
	float sectorStep = 2 * M_PI / sectorCount;
	float stackStep = M_PI / stackCount;

	for (unsigned int i = 0; i <= stackCount; ++i)
	{
		float stackAngle = M_PI / 2 - i * stackStep;
		float xy = radius * cosf(stackAngle);
		float z = radius * sinf(stackAngle);

		for (unsigned int j = 0; j <= sectorCount; ++j)
		{
			float sectorAngle = j * sectorStep;
			float x = xy * cosf(sectorAngle);
			float y = xy * sinf(sectorAngle);

			// Add vertex position 
			vertices.push_back(x);
			vertices.push_back(y);
			vertices.push_back(z);

			// Add texture coordinates
			float u = (float)j / sectorCount;
			float v = (float)i / stackCount;
			vertices.push_back(u);
			vertices.push_back(v);


			// Add indices
			if (i < stackCount && j < sectorCount)
			{
				int k1 = i * (sectorCount + 1) + j;
				int k2 = k1 + 1;
				int k3 = (i + 1) * (sectorCount + 1) + j;
				int k4 = k3 + 1;

				indices.push_back(k1);
				indices.push_back(k3);
				indices.push_back(k2);

				indices.push_back(k2);
				indices.push_back(k3);
				indices.push_back(k4);
			}
		}
	}
	// Generate and bind VAO
	glGenVertexArrays(1, &VAO_SPHERE2);
	glBindVertexArray(VAO_SPHERE2);

	// Generate and bind VBO
	glGenBuffers(1, &VBO_SPHERE2);
	glBindBuffer(GL_ARRAY_BUFFER, VBO_SPHERE2);
	glBufferData(GL_ARRAY_BUFFER, vertices.size() * sizeof(float), vertices.data(), GL_STATIC_DRAW);

	// Generate EBO and load indices into it
	glGenBuffers(1, &EBO_SPHERE2);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO_SPHERE2);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.size() * sizeof(unsigned int), indices.data(), GL_STATIC_DRAW);

	// Configure vertex attributes
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)0);  // Vertex position
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)(3 * sizeof(float)));  // Texture coordinates
	glEnableVertexAttribArray(1);

	// Unbind VAO
	glBindVertexArray(0);

}

void CreateCube() {			// to create the pad of butter
	GLfloat vertices[] = {
		// positions          // texture coords // normals
   // Bottom Face
   -1.0f, -0.2f, -1.0f,  0.0f, 0.0f,  0.0f, -1.0f, 0.0f,
	1.0f, -0.2f, -1.0f,  1.0f, 0.0f,  0.0f, -1.0f, 0.0f,
	1.0f, -0.2f,  1.0f,  1.0f, 1.0f,  0.0f, -1.0f, 0.0f,
	1.0f, -0.2f,  1.0f,  1.0f, 1.0f,  0.0f, -1.0f, 0.0f,
   -1.0f, -0.2f,  1.0f,  0.0f, 1.0f,  0.0f, -1.0f, 0.0f,
   -1.0f, -0.2f, -1.0f,  0.0f, 0.0f,  0.0f, -1.0f, 0.0f,
   // Top Face
   -1.0f,  0.2f, -1.0f,  0.0f, 0.0f,  0.0f, 1.0f, 0.0f,
	1.0f,  0.2f, -1.0f,  1.0f, 0.0f,  0.0f, 1.0f, 0.0f,
	1.0f,  0.2f,  1.0f,  1.0f, 1.0f,  0.0f, 1.0f, 0.0f,
	1.0f,  0.2f,  1.0f,  1.0f, 1.0f,  0.0f, 1.0f, 0.0f,
   -1.0f,  0.2f,  1.0f,  0.0f, 1.0f,  0.0f, 1.0f, 0.0f,
   -1.0f,  0.2f, -1.0f,  0.0f, 0.0f,  0.0f, 1.0f, 0.0f,
   // Front Face
   -1.0f, -0.2f,  1.0f,  0.0f, 0.0f,   0.0f, 0.0f, 1.0f,
	1.0f, -0.2f,  1.0f,  1.0f, 0.0f,   0.0f, 0.0f, 1.0f,
	1.0f,  0.2f,  1.0f,  1.0f, 1.0f,   0.0f, 0.0f, 1.0f,
	1.0f,  0.2f,  1.0f,  1.0f, 1.0f,   0.0f, 0.0f, 1.0f,
   -1.0f,  0.2f,  1.0f,  0.0f, 1.0f,   0.0f, 0.0f, 1.0f,
   -1.0f, -0.2f,  1.0f,  0.0f, 0.0f,   0.0f, 0.0f, 1.0f,
   // Back Face
   -1.0f, -0.2f, -1.0f,  0.0f, 0.0f,  0.0f, 0.0f, -1.0f,
	1.0f, -0.2f, -1.0f,  1.0f, 0.0f,  0.0f, 0.0f, -1.0f,
	1.0f,  0.2f, -1.0f,  1.0f, 1.0f,  0.0f, 0.0f, -1.0f,
	1.0f,  0.2f, -1.0f,  1.0f, 1.0f,  0.0f, 0.0f, -1.0f,
   -1.0f,  0.2f, -1.0f,  0.0f, 1.0f,  0.0f, 0.0f, -1.0f,
   -1.0f, -0.2f, -1.0f,  0.0f, 0.0f,  0.0f, 0.0f, -1.0f,
   // Right face
	1.0f, -0.2f, -1.0f,  0.0f, 0.0f,  1.0f, 0.0f, 0.0f,
	1.0f, -0.2f,  1.0f,  1.0f, 0.0f,  1.0f, 0.0f, 0.0f,
	1.0f,  0.2f,  1.0f,  1.0f, 1.0f,  1.0f, 0.0f, 0.0f,
	1.0f,  0.2f,  1.0f,  1.0f, 1.0f,  1.0f, 0.0f, 0.0f,
	1.0f,  0.2f, -1.0f,  0.0f, 1.0f,  1.0f, 0.0f, 0.0f,
	1.0f, -0.2f, -1.0f,  0.0f, 0.0f,  1.0f, 0.0f, 0.0f,
	// Left face
	-1.0f, -0.2f, -1.0f,  0.0f, 0.0f, -1.0f, 0.0f, 0.0f,
	-1.0f, -0.2f,  1.0f,  1.0f, 0.0f, -1.0f, 0.0f, 0.0f,
	-1.0f,  0.2f,  1.0f,  1.0f, 1.0f, -1.0f, 0.0f, 0.0f,
	-1.0f,  0.2f,  1.0f,  1.0f, 1.0f, -1.0f, 0.0f, 0.0f,
	-1.0f,  0.2f, -1.0f,  0.0f, 1.0f, -1.0f, 0.0f, 0.0f,
	-1.0f, -0.2f, -1.0f,  0.0f, 0.0f, -1.0f, 0.0f, 0.0f
	};

	glGenVertexArrays(1, &VAO_CUBE);
	glBindVertexArray(VAO_CUBE);

	glGenBuffers(1, &VBO_CUBE);
	glBindBuffer(GL_ARRAY_BUFFER, VBO_CUBE);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

	// Position attribute
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);

	// Normal attribute
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
	glEnableVertexAttribArray(1);

	// Texture Coordinate attribute
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));
	glEnableVertexAttribArray(2);

	glBindBuffer(GL_ARRAY_BUFFER, 0);

	glBindVertexArray(0);

}

void AddShader(GLuint theProgram, const char* shaderCode, GLenum shaderType)
{
	GLuint theShader = glCreateShader(shaderType);

	const GLchar* theCode[1];
	theCode[0] = shaderCode;

	GLint codeLength[1];
	codeLength[0] = strlen(shaderCode);

	glShaderSource(theShader, 1, theCode, codeLength);
	glCompileShader(theShader);

	GLint result = 0;
	GLchar eLog[1024] = { 0 };

	glGetShaderiv(theShader, GL_COMPILE_STATUS, &result);
	if (!result) 
	{
		glGetShaderInfoLog(theShader, 1024, NULL, eLog);
		fprintf(stderr, "Error compiling the %d shader: '%s'\n", shaderType, eLog);
		return;
	}

	glAttachShader(theProgram, theShader);
}

void ValidateProgram(GLuint theProgram)
{
	GLint result = 0;
	GLchar eLog[1024] = { 0 };

	//glLinkProgram(theProgram);
	glGetProgramiv(theProgram, GL_LINK_STATUS, &result);
	if (!result)
	{
		glGetProgramInfoLog(theProgram, sizeof(eLog), NULL, eLog);
		printf("Error linking program: '%s'\n", eLog);
		return;
	}

	glValidateProgram(theProgram);
	glGetProgramiv(theProgram, GL_VALIDATE_STATUS, &result);
	if (!result)
	{
		glGetProgramInfoLog(theProgram, sizeof(eLog), NULL, eLog);
		printf("Error validating program: '%s'\n", eLog);
		return;
	}
}

void CompileShaders()
{
	shaderTexture = glCreateProgram();

	if (!shaderTexture)
	{
		printf("Failed to create texture shader\n");
		return;
	}

	AddShader(shaderTexture, vShader, GL_VERTEX_SHADER);
	AddShader(shaderTexture, fShaderTexture, GL_FRAGMENT_SHADER);

	GLint result = 0;
	GLchar eLog[1024] = { 0 };

	glLinkProgram(shaderTexture);
	glGetProgramiv(shaderTexture, GL_LINK_STATUS, &result);
	if (!result)
	{
		glGetProgramInfoLog(shaderTexture, sizeof(eLog), NULL, eLog);
		printf("Error linking texture program: '%s'\n", eLog);
		return;
	}

	ValidateProgram(shaderTexture);

	lightShader = glCreateProgram();
	if (!lightShader)
	{
		printf("Failed to create light shader\n");
	}

	AddShader(lightShader, vlightShader, GL_VERTEX_SHADER);
	AddShader(lightShader, flightShader, GL_FRAGMENT_SHADER);

	glLinkProgram(lightShader);
	glGetProgramiv(lightShader, GL_LINK_STATUS, &result);
	if (!result)
	{
		glGetProgramInfoLog(lightShader, sizeof(eLog), NULL, eLog);
		printf("Error linking light program: '%s'\n", eLog);
		return;
	}

	ValidateProgram(lightShader);
}


glm::vec3 cameraPosition = glm::vec3(0.0f, 1.0f, 4.0f);
float cameraSpeed = 0.05f;
float cameraRotationSpeed = 0.1f;
float cameraYaw = -90.0f;
float cameraPitch = 0.0f;

bool firstMouse = true;
float lastMouseX = 0.0f;
float lastMouseY = 0.0f;
bool orthographic = false;

glm::vec3 getCameraFront()
{
	glm::vec3 front;
	front.x = cos(glm::radians(cameraYaw)) * cos(glm::radians(cameraPitch));
	front.y = sin(glm::radians(cameraPitch));
	front.z = sin(glm::radians(cameraYaw)) * cos(glm::radians(cameraPitch));
	return glm::normalize(front);
}

glm::vec3 getCameraUp()
{
	return glm::vec3(0.0f, 1.0f, 0.0f);
}


void keyCallback(GLFWwindow* window, int key, int scancode, int action, int mods) {
	if (key == GLFW_KEY_W && (action == GLFW_PRESS || action == GLFW_REPEAT)) {
		cameraPosition += cameraSpeed * getCameraFront(); // Move forward
	}
	else if (key == GLFW_KEY_S && (action == GLFW_PRESS || action == GLFW_REPEAT)) {
		cameraPosition -= cameraSpeed * getCameraFront(); // Move backward
	}
	else if (key == GLFW_KEY_A && (action == GLFW_PRESS || action == GLFW_REPEAT)) {
		cameraPosition -= cameraSpeed * glm::normalize(glm::cross(getCameraFront(), getCameraUp())); // Move left
	}
	else if (key == GLFW_KEY_D && (action == GLFW_PRESS || action == GLFW_REPEAT)) {
		cameraPosition += cameraSpeed * glm::normalize(glm::cross(getCameraFront(), getCameraUp())); // Move right
	}
	else if (key == GLFW_KEY_Q && (action == GLFW_PRESS || action == GLFW_REPEAT)) {
		cameraPosition += cameraSpeed * getCameraUp(); // Move up
	}
	else if (key == GLFW_KEY_E && (action == GLFW_PRESS || action == GLFW_REPEAT)) {
		cameraPosition -= cameraSpeed * getCameraUp(); // Move down
	}
	else if (key == GLFW_KEY_P && action == GLFW_PRESS) {
		orthographic = !orthographic; // Toggle between orthographic and perspective views
	}
	else if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS) {
		glfwSetWindowShouldClose(window, GLFW_TRUE);
	}
}



void mouseCallback(GLFWwindow* window, double xpos, double ypos) 
{
	if (firstMouse)
	{
		lastMouseX = xpos;
		lastMouseY = ypos;
		firstMouse = false;
	}

	float xoffset = xpos - lastMouseX;
	float yoffset = lastMouseY - ypos; // reversed since y-coordinates range from bottom to top

	lastMouseX = xpos;
	lastMouseY = ypos;

	float sensitivity = 0.1f;
	xoffset *= sensitivity;
	yoffset *= sensitivity;

	cameraYaw += xoffset;
	cameraPitch += yoffset;

	// Clamp the camera pitch to avoid flipping
	if (cameraPitch > 89.0f)
		cameraPitch = 89.0f;
	if (cameraPitch < -89.0f)
		cameraPitch = -89.0f;
}

void scrollCallback(GLFWwindow* window, double xoffset, double yoffset)
{
	cameraSpeed += 0.01f * yoffset;
	if (cameraSpeed < 0.01f)
		cameraSpeed = 0.01f;
}

int main()
{
	// Initialise GLFW
	if (!glfwInit())
	{
		printf("GLFW initialisation failed!");
		glfwTerminate();
		return 1;
	}

	// Setup GLFW window properties
	// OpenGL version
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	// Core Profile
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
	// Allow Forward Compatbility
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);

	// Create the window
	GLFWwindow* mainWindow = glfwCreateWindow(WIDTH, HEIGHT, "Test Window", NULL, NULL);
	if (!mainWindow)
	{
		printf("GLFW window creation failed!");
		glfwTerminate();
		return 1;
	}

	// Get Buffer Size information
	int bufferWidth, bufferHeight;
	glfwGetFramebufferSize(mainWindow, &bufferWidth, &bufferHeight);

	// Set context for GLEW to use
	glfwMakeContextCurrent(mainWindow);

	// Capture the mouse
	glfwSetInputMode(mainWindow, GLFW_CURSOR, GLFW_CURSOR_DISABLED);


	// Allow modern extension features
	glewExperimental = GL_TRUE;

	if (glewInit() != GLEW_OK)
	{
		printf("GLEW initialisation failed!");
		glfwDestroyWindow(mainWindow);
		glfwTerminate();
		return 1;
	}

	glEnable(GL_DEPTH_TEST);

	// Setup Viewport size
	glViewport(0, 0, bufferWidth, bufferHeight);

	CreateTorus();
	CreatePlane();
	CreateCylinder(false);
	CreateCylinder(true);
	CreateCylinder2();
	CreateSphere();
	CreateSphere2();
	CreateCube();
	CompileShaders();


	glm::mat4 modelTorus = glm::mat4(1.0f);
	glm::mat4 modelPlane = glm::mat4(1.0f);
	glm::mat4 modelCylinder = glm::mat4(1.0f);
	glm::mat4 modelInnerCylinder = glm::mat4(1.0f);
	glm::mat4 modelCylinder2 = glm::mat4(1.0f);
	glm::mat4 modelSphere = glm::mat4(1.0f);
	glm::mat4 modelShpere2 = glm::mat4(1.0f);
	glm::mat4 modelCube = glm::mat4(1.0f);


	// Apply transformations to model matrices
	modelTorus = glm::rotate(modelTorus, glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
	modelTorus = glm::translate(modelTorus, glm::vec3(0.7f, 0.6f, 0.0f));

	modelPlane = glm::translate(modelPlane, glm::vec3(0.0f, -0.1f, 0.0f));
	modelPlane = glm::rotate(modelPlane, glm::radians(90.0f), glm::vec3(0.5f, 0.0f, 0.0f));

	modelCylinder = glm::translate(modelCylinder, glm::vec3(-0.7f, -0.1f, -0.5));
	//modelCylinder = glm::rotate(modelCylinder, glm::radians(90.0f), glm::vec3(0.0f, 1.0f, 0.0f));
	modelInnerCylinder = glm::translate(modelInnerCylinder, glm::vec3(-0.7f, -0.1f, -0.5));

	modelCylinder2 = glm::translate(modelCylinder2, glm::vec3(-0.8f, -0.1f, 0.5f));
	//modelCylinder2 = glm::rotate(modelCylinder2, glm::radians(90.0f), glm::vec3(0.0f, 1.0f, 0.0f));

	//modelSphere = glm::rotate(modelSphere, glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
	modelSphere = glm::translate(modelSphere, glm::vec3(0.7f, 0.2f, -0.5f));

	modelCube = glm::translate(modelCube, glm::vec3(-0.8f, -0.05f, 0.5f));
	modelCube = glm::scale(modelCube, glm::vec3(0.1f));

	// Define the projection and view matrices
	glm::mat4 projection = glm::perspective(glm::radians(45.0f), (float)bufferWidth / (float)bufferHeight, 0.1f, 100.0f);
	glm::mat4 view = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.0f, -3.0f));

	float rotationAngle = 45.0f;

	view = glm::rotate(view, glm::radians(rotationAngle), glm::vec3(0.5f, 0.0f, 0.0f));

	GLuint mvpLocationTexture = glGetUniformLocation(shaderTexture, "mvp");

	glfwSetKeyCallback(mainWindow, keyCallback);
	glfwSetCursorPosCallback(mainWindow, mouseCallback);
	glfwSetScrollCallback(mainWindow, scrollCallback);

	GLuint texture = loadTexture("../../7-1 Project/wood.jpg");			// platter texture 
	GLuint texture1 = loadTexture("../../7-1 Project/glass1.jpg");		// glass texture
	GLuint texture2 = loadTexture("../../7-1 Project/pancake.jpg");		// pancake texture
	GLuint texture3 = loadTexture("../../7-1 Project/doughnut.jfif");		// doughnut texture
	GLuint texture4 = loadTexture("../../7-1 Project/tomato.jfif");		// tomato texture
	GLuint texture5 = loadTexture("../../7-1 Project/butter.jpg");		// butter texture
	GLuint texture6 = loadTexture("../../7-1 Project/juice.jpg");		// juice texture

	glm::vec3 lightColor1 = glm::vec3(1.0f, 0.839f, 0.667f);
	glm::vec3 lightColor2 = glm::vec3(1.0f, 0.839f, 0.667f);

	GLint lightPosLoc1 = glGetUniformLocation(shaderTexture, "lightPos1");
	GLint lightColorLoc1 = glGetUniformLocation(shaderTexture, "lightColor1");
	GLint lightPosLoc2 = glGetUniformLocation(shaderTexture, "lightPos2");
	GLint lightColorLoc2 = glGetUniformLocation(shaderTexture, "lightColor2");
	GLint viewPosLoc = glGetUniformLocation(shaderTexture, "viewPos");
	GLint specularColorLoc = glGetUniformLocation(shaderTexture, "specularColor");
	GLint shininessLoc = glGetUniformLocation(shaderTexture, "shininess"); 
	GLint textureLoc = glGetUniformLocation(shaderTexture, "texture");
	GLint modelLocationTexture = glGetUniformLocation(shaderTexture, "model");
	GLint viewLocationTexture = glGetUniformLocation(shaderTexture, "view");
	GLint projectionLocationTexture = glGetUniformLocation(shaderTexture, "projection");




	// Loop until window closed
	while (!glfwWindowShouldClose(mainWindow))
	{
		// Get + Handle user input events
		glfwPollEvents();

		glm::mat4 projection;
		if (orthographic) {
			float orthoSize = 3.0f;
			projection = glm::ortho(-orthoSize, orthoSize, -orthoSize, orthoSize, 0.1f, 100.0f);
		}
		else {
			projection = glm::perspective(glm::radians(45.0f), (float)bufferWidth / (float)bufferHeight, 0.1f, 100.0f);
		}


		// Clear window
		glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);



		glm::mat4 view = glm::lookAt(cameraPosition, cameraPosition + getCameraFront(), getCameraUp());
		

		glm::vec3 lightPos1 = glm::vec3(0.0f, 5.0f, 3.0f);
		glm::vec3 lightPos2 = glm::vec3(0.0f, 5.0f, -3.0f);


		glUseProgram(shaderTexture);

		glUniform3fv(lightPosLoc1, 1, glm::value_ptr(lightPos1));
		glUniform3fv(lightColorLoc1, 1, glm::value_ptr(lightColor1));
		glUniform3fv(lightPosLoc2, 1, glm::value_ptr(lightPos2));
		glUniform3fv(lightColorLoc2, 1, glm::value_ptr(lightColor2));
		

		glm::vec3 cameraPosition = glm::vec3(0.0f, 0.0f, 3.0f);  
		glUniform3fv(viewPosLoc, 1, glm::value_ptr(cameraPosition));


		// setting the texture for the platter
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, texture);
		glUniform1i(glGetUniformLocation(shaderTexture, "texture1"), 0);

		//Set the Model, View, and Projection matrices for the plane and render the platter
		glUniformMatrix4fv(modelLocationTexture, 1, GL_FALSE, glm::value_ptr(modelPlane));
		glUniformMatrix4fv(viewLocationTexture, 1, GL_FALSE, glm::value_ptr(view));
		glUniformMatrix4fv(projectionLocationTexture, 1, GL_FALSE, glm::value_ptr(projection));

		//Set the light porperties of the platter
		glUniform3fv(lightPosLoc1, 1, glm::value_ptr(lightPos1));
		glUniform3fv(lightColorLoc1, 1, glm::value_ptr(lightColor1));
		glUniform3fv(lightPosLoc2, 1, glm::value_ptr(lightPos2));
		glUniform3fv(lightColorLoc2, 1, glm::value_ptr(lightColor2));

		// Set specular properties
		glm::vec3 specularColor = glm::vec3(1.0f, 1.0f, 1.0f); 
		float shininess = 20.0f; 
		glUniform3fv(specularColorLoc, 1, glm::value_ptr(specularColor));
		glUniform1f(shininessLoc, shininess);

		glBindVertexArray(VAO_PLANE);
		glDrawArrays(GL_TRIANGLES, 0, 6);
		glBindVertexArray(0);
		

		// setting the texture for the glass
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, texture1);
		glUniform1i(glGetUniformLocation(shaderTexture, "texture1"), 0);


		// Set the Model, View and Projection matrices for the glass
		glUniformMatrix4fv(modelLocationTexture, 1, GL_FALSE, glm::value_ptr(modelCylinder));
		glUniformMatrix4fv(viewLocationTexture, 1, GL_FALSE, glm::value_ptr(view));
		glUniformMatrix4fv(projectionLocationTexture, 1, GL_FALSE, glm::value_ptr(projection));
		glBindVertexArray(VAO_CYLINDER);
		glDrawElements(GL_TRIANGLES, indices.size(), GL_UNSIGNED_INT, 0);
		glBindVertexArray(0);

		// setting the texture for the juice
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, texture6);
		glUniform1i(glGetUniformLocation(shaderTexture, "texture1"), 0);


		// Set the Model, View and Projection matrices for the juice
		glUniformMatrix4fv(modelLocationTexture, 1, GL_FALSE, glm::value_ptr(modelInnerCylinder));
		glUniformMatrix4fv(viewLocationTexture, 1, GL_FALSE, glm::value_ptr(view));
		glUniformMatrix4fv(projectionLocationTexture, 1, GL_FALSE, glm::value_ptr(projection));
		glBindVertexArray(VAO_INNER_CYLINDER);
		glDrawElements(GL_TRIANGLES, indices.size(), GL_UNSIGNED_INT, 0);
		glBindVertexArray(0);

		// Setting the texture fo the pancake
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, texture2);
		glUniform1i(glGetUniformLocation(shaderTexture, "texture1"), 0);

		//Set the Model, View and Projection matrices for the pancake
		glUniformMatrix4fv(modelLocationTexture, 1, GL_FALSE, glm::value_ptr(modelCylinder2));
		glUniformMatrix4fv(viewLocationTexture, 1, GL_FALSE, glm::value_ptr(view));
		glUniformMatrix4fv(projectionLocationTexture, 1, GL_FALSE, glm::value_ptr(projection));
		glBindVertexArray(VAO_CYLINDER2);
		glDrawElements(GL_TRIANGLES, indices.size(), GL_UNSIGNED_INT, 0);
		glBindVertexArray(0);

		// Setting the texture for the cube
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, texture5); //replace cubeTexture with the name of your cube texture
		glUniform1i(glGetUniformLocation(shaderTexture, "texture1"), 0);

		// Set the Model, View and Projection matrices for the cube
		glUniformMatrix4fv(modelLocationTexture, 1, GL_FALSE, glm::value_ptr(modelCube));
		glUniformMatrix4fv(viewLocationTexture, 1, GL_FALSE, glm::value_ptr(view));
		glUniformMatrix4fv(projectionLocationTexture, 1, GL_FALSE, glm::value_ptr(projection));

		// Render the cube
		glBindVertexArray(VAO_CUBE);
		glDrawArrays(GL_TRIANGLES, 0, 36); // 36 vertices for a cube with 6 faces, 2 triangles per face
		glBindVertexArray(0);
		

		// Setting the texture for the doughnut
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, texture3);
		glUniform1i(glGetUniformLocation(shaderTexture, "texture1"), 0);

		// Set the Model, View and Projection matrices for the doughnut
		glUniformMatrix4fv(modelLocationTexture, 1, GL_FALSE, glm::value_ptr(modelTorus));
		glUniformMatrix4fv(viewLocationTexture, 1, GL_FALSE, glm::value_ptr(view));
		glUniformMatrix4fv(projectionLocationTexture, 1, GL_FALSE, glm::value_ptr(projection));
		glBindVertexArray(VAO);
		glDrawElements(GL_TRIANGLES, indices.size(), GL_UNSIGNED_INT, 0);
		glBindVertexArray(0);
		

		// Setting the texture for the tomato
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, texture4);
		glUniform1i(glGetUniformLocation(shaderTexture, "texture1"), 0);

		// Set the Model, View and Projection matrices for the Tomato
		glUniformMatrix4fv(modelLocationTexture, 1, GL_FALSE, glm::value_ptr(modelSphere));
		glUniformMatrix4fv(viewLocationTexture, 1, GL_FALSE, glm::value_ptr(view));
		glUniformMatrix4fv(projectionLocationTexture, 1, GL_FALSE, glm::value_ptr(projection));
		glBindVertexArray(VAO_SPHERE);
		glDrawElements(GL_TRIANGLES, indices.size(), GL_UNSIGNED_INT, 0);
		glBindVertexArray(0);

		glBindTexture(GL_TEXTURE_2D, 0);
		
		glUseProgram(lightShader);

		GLint lightModelLoc = glGetUniformLocation(lightShader, "model");
		GLint LightViewLoc = glGetUniformLocation(lightShader, "view");
		GLint lightProjectionLoc = glGetUniformLocation(lightShader, "projection");

		// First Light
		glm::mat4 lightModel = glm::mat4(1.0f);
		lightModel = glm::translate(lightModel, lightPos1);
		lightModel = glm::scale(lightModel, glm::vec3(0.7f));
		glUniformMatrix4fv(lightModelLoc, 1, GL_FALSE, glm::value_ptr(lightModel));
		glUniformMatrix4fv(LightViewLoc, 1, GL_FALSE, glm::value_ptr(view));
		glUniformMatrix4fv(lightProjectionLoc, 1, GL_FALSE, glm::value_ptr(projection));

		glBindVertexArray(VAO_SPHERE2);
		glDrawElements(GL_TRIANGLES, indices.size(), GL_UNSIGNED_INT, 0);

		// Second Light
		lightModel = glm::mat4(1.0f);
		lightModel = glm::translate(lightModel, lightPos2);
		lightModel = glm::scale(lightModel, glm::vec3(0.7f));
		glUniformMatrix4fv(lightModelLoc, 1, GL_FALSE, glm::value_ptr(lightModel));

		glDrawElements(GL_TRIANGLES, indices.size(), GL_UNSIGNED_INT, 0);

		glBindVertexArray(0);

		glUseProgram(0);

		glfwSwapBuffers(mainWindow);
	}

	return 0;
}